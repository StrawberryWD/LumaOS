LumaOS 5.0 (Day 75) - VMware Workstation files
1) 双击 LumaOS-iso.vmx  -> 从 ISO 启动（固件 = BIOS，只挂光驱）
2) 双击 LumaOS-hd.vmx   -> 从硬盘 vmdk 启动（固件 = BIOS，不依赖 El Torito，用来区分“ISO 引导问题”还是“其它问题”）
若自己新建虚拟机：固件必须选 BIOS（不能是 UEFI），客户机系统选“其他”，光驱设为启动时连接，并把启动顺序设为 CD-ROM 优先。
